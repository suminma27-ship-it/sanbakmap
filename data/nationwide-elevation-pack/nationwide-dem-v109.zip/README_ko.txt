산박지도 v109 전국 고도 대조 패키지

전국 산림청 원본 산코드 2,902개 중 2,723개에서 원본 연결망 간선과 고도 표본 대응을 확인했습니다.
원본 간선 67,185개 중 53,034개가 대조 조건을 통과했습니다.

여기에 포함된 32개 버킷은 일괄 변환 결과이며 모두 웹에 배포된 것은 아닙니다.
GitHub Pages 첫 적용은 설악산 산림청, 오대산 노인봉, 계룡산 등 3곳의 산림청 연결망입니다.
고도 원본 래스터의 실제 해상도/수직기준 및 현재 산행 통행 허가는 검증되지 않았습니다.

파일 구성:
 data/nationwide-elevation/bucket-00..31.json  고도 대응 버킷
 data/nationwide-elevation/coverage-v109.json  산별 검사 기록
 tools/build_v109.py  동일 규칙으로 재생성하는 스크립트(pyproj 필요)

재생성: python tools/build_v109.py --geometries [v102 원본 연결망.zip] --elevations [output_elevation.zip] --output [폴더]
