#!/usr/bin/env python3
"""Sanbakmap v109: conservative lineage matching of 2016 forest edges to DEM-annotated GeoJSON vertices.

Input: archived user source ZIPs (output_elevation.zip; v102 original geometry review bundle).
Outputs: source-locked 90m compact elevation packs, coverage report, deployment index candidate.

Important: source DEM raster resolution, vertical datum and present trail access status are unverified.
This program does not infer passage across unconnected graph edges.
"""
import argparse,base64,collections,csv,hashlib,io,json,math,os,sys,zipfile
from pathlib import Path
from pyproj import Transformer

DEFAULT_GEOM='/mnt/data/files/산박지도_v102_전국원본GIS_기하접점진단.zip'
DEFAULT_ALT='/mnt/data/files/output_elevation.zip'
FOREST_SHA='7426dbf4bbf07ad31524a16eabe9dfad8f358a75ac519dcf3f09c4ebc178b76a'
TRANSFORM=Transformer.from_crs('EPSG:4326','EPSG:5179',always_xy=True)
DIST_TOL_M=.22
DIST_REL_TOL=.008
HEIGHT_TOL_M=.1
CODE='428302602'

def coords_xy(arr):
    lons=[p[0] for p in arr]; lats=[p[1] for p in arr]
    xs,ys=TRANSFORM.transform(lons,lats)
    return list(zip(xs,ys))

def dist(a,b):return math.hypot(a[0]-b[0],a[1]-b[1])

def signature(p):return (round(p[0]),round(p[1]))

def estimate_length(xy):
    return sum(math.hypot(q[0]-p[0],q[1]-p[1]) for p,q in zip(xy,xy[1:]))

def zig(n):return n*2 if n>=0 else -2*n-1

def encode(heights):
    raw=bytearray();old=0
    for h in heights:
        cur=round(h*10);n=zig(cur-old);old=cur
        while n>=128:
            raw.append((n&127)|128);n>>=7
        raw.append(n)
    return base64.urlsafe_b64encode(raw).decode().rstrip('=')

def encode_edge(edge,part,heights):
    st,en=edge[4],edge[5]
    if st<0 or en>=len(part) or en<=st:return None
    pts=part[st:en+1];h=heights[st:en+1]
    if any(q is None or not isinstance(q,(int,float)) or not math.isfinite(q) or q<-500 or q>9000 for q in h):return None
    lengths=[0.0]
    for a,b in zip(pts,pts[1:]):lengths.append(lengths[-1]+dist(a,b))
    raw=lengths[-1]
    L=edge[2]
    if not raw or abs(raw-L)>max(1.5,L*DIST_REL_TOL):return None
    samples=[];k=0
    for j in range(math.ceil(L/90)+1):
        target=min(L,j*90.0)
        pos=target/L*raw
        while k+1<len(lengths)-1 and lengths[k+1]<pos:k+=1
        width=lengths[k+1]-lengths[k]
        mix=(pos-lengths[k])/width if width>0 else 0
        val=h[k]+(h[k+1]-h[k])*mix
        samples.append(val)
    return encode(samples)

def geo_parts(d):
    allparts=[]
    for feat in d.get('features',[]):
        if feat.get('properties',{}).get('feature_kind')!='trail':continue
        geom=feat.get('geometry') or {};ty=geom.get('type')
        if ty not in ('LineString','MultiLineString'):continue
        raw=geom['coordinates']
        segments=[raw] if ty=='LineString' else raw
        for part in segments:
            if len(part)<2:continue
            projected=coords_xy(part)
            heights=[p[2] if len(p)>=3 else None for p in part]
            allparts.append((projected,heights))
    return allparts

def audit_mountain(code,g,d):
    edges=g['edges'];nodes=[(p[0]/10,p[1]/10) for p in g['nodes']]
    entries=collections.defaultdict(list)
    for i,e in enumerate(edges):
        if not isinstance(e,list) or len(e)!=6:return None,{'code':code,'reason':'bad_graph_edge'}
        entries[e[3]].append((i,e))
    allparts=geo_parts(d)
    # Index original-line start/end coordinates at 1m cells; verify at 0.22m and each split boundary.
    starts=collections.defaultdict(list)
    for i,(xy,h) in enumerate(allparts):
        for inverted,p in ((False,xy[0]),(True,xy[-1])):
            starts[signature(p)].append((i,inverted))
    packed={}; identities={};matchedparts=0; unmatched=collections.Counter(); conflicting=0
    seenparts=set()
    for part_i,listed in entries.items():
        listed.sort(key=lambda it:it[1][4]);first=listed[0][1]
        if first[4]!=0:
            unmatched['missing_part_start']+=len(listed);continue
        anchor=nodes[first[0]]
        candidates=set()
        xx,yy=signature(anchor)
        for x in (xx-1,xx,xx+1):
            for y in (yy-1,yy,yy+1):
                for c in starts.get((x,y),[]):candidates.add(c)
        eligible=[]
        endmax=max(e[5] for _,e in listed)
        for pi,reverse in candidates:
            rawxy,rawheight=allparts[pi];xy=rawxy[::-1] if reverse else rawxy;heights=rawheight[::-1] if reverse else rawheight
            if endmax>=len(xy) or len(xy)!=endmax+1:continue
            if dist(anchor,xy[0])>DIST_TOL_M:continue
            valid=True
            for _,e in listed:
                st,en=e[4],e[5]
                if dist(xy[st],nodes[e[0]])>DIST_TOL_M or dist(xy[en],nodes[e[1]])>DIST_TOL_M:
                    valid=False;break
                measured=estimate_length(xy[st:en+1])
                if abs(measured-e[2])>max(1.5,e[2]*DIST_REL_TOL):valid=False;break
            if valid:eligible.append((pi,reverse,xy,heights))
        if not eligible:
            unmatched['not_verified_geometry']+=len(listed);continue
        # Multiple coincident lines are only valid if DEM heights agree at every vertex.
        if len(eligible)>1:
            base=eligible[0][3]
            disagree=False
            for _,_,_,alt in eligible[1:]:
                if len(base)!=len(alt) or any(x is None or y is None or abs(x-y)>HEIGHT_TOL_M for x,y in zip(base,alt)):
                    disagree=True;break
            if disagree:
                conflicting+=len(listed);unmatched['ambiguous_source']+=len(listed);continue
        pi,reverse,xy,heights=eligible[0]
        if pi in seenparts:
            # Source graph may contain coincident duplicate GIS features. The geometry and DEM match is still valid.
            pass
        seenparts.add(pi);matchedparts+=1
        for ei,e in listed:
            enc=encode_edge(e,xy,heights)
            if enc is None:unmatched['missing_elevation_or_distance']+=1;continue
            packed[str(ei)]=enc
            identities[str(ei)]=e[:]
    return (packed,identities),{'code':code,'graphEdges':len(edges),'matchedEdges':len(packed),'missingEdges':len(edges)-len(packed),
                                'graphParts':len(entries),'matchedParts':matchedparts,'sourceElevationParts':len(allparts),
                                'ambiguous':conflicting,'unmatched':dict(unmatched)}

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--geometries',default=DEFAULT_GEOM);ap.add_argument('--elevations',default=DEFAULT_ALT)
    ap.add_argument('--output',default='/mnt/data/sanbak-v109/build');ap.add_argument('--codes',nargs='*');args=ap.parse_args()
    dest=Path(args.output);dest.mkdir(parents=True,exist_ok=True)
    zgeom=zipfile.ZipFile(args.geometries);zalt=zipfile.ZipFile(args.elevations)
    altfiles=set(zalt.namelist());wanted=set(args.codes or [])
    archive_hash=hashlib.sha256(Path(args.elevations).read_bytes()).hexdigest()
    print('Archive SHA256:',archive_hash,flush=True)
    report=[];buckets={};totals=collections.Counter();count=0
    for filename in sorted(n for n in zgeom.namelist() if n.startswith('graph-bucket-') and n.endswith('.json')):
        bucket=filename[13:15]
        graphs=json.loads(zgeom.read(filename))['mountains']
        batch={}
        for code,g in graphs.items():
            if wanted and code not in wanted:continue
            name='output_elevation/geojson_elevation/'+code+'.geojson'
            if name not in altfiles:
                report.append({'code':code,'reason':'no_dem_geojson','graphEdges':len(g['edges']),'matchedEdges':0});continue
            data=json.loads(zalt.read(name))
            result,audit=audit_mountain(code,g,data)
            report.append(audit);totals['graphEdges']+=audit['graphEdges'];totals['matchedEdges']+=audit['matchedEdges'];totals['matchedMountains']+=bool(audit['matchedEdges']);count+=1
            if result and result[0]:
                packed,identities=result
                batch[code]={
                    'schema':'sanbak-original-edge-dem-packed-v108','mountainCode':code,'sourceKind':'forest',
                    'graphArchiveSHA256':FOREST_SHA,'nodeCount':len(g['nodes']),'edgeCount':len(g['edges']),
                    'dem':{'sha256':archive_hash,
                           'name':'전국 DEM 표본 포함 GeoJSON (2026-11-04 가공 산출물)',
                           'hashKind':'annotated-geojson-archive',
                           'verticalDatum':'원본 DEM 수직기준 미기재','units':'m','resolutionMeters':None,
                           'sampleMethod':'source-geojson-dem-vertices-to-original-edge',
                           'sourceRasterResolutionVerified':False,
                           'sourceData':'산박지도 output_elevation.zip / geojson_elevation',
                           'referenceDate':'2016-12-31'},
                    'accessVerified':False,'spacingMeters':90,'samples':packed,'edgeIdentities':identities,
                    'status':'2016 forestry historic line geometry; DEM vertex samples, source raster unverified, passage unverified'}
        if batch:
            out={'schema':'sanbak-dem-bucket-v109','bucket':bucket,'mountains':batch,
                 'source':'user-supplied output_elevation.zip; 2016 source geometry; 2026-11-04 DEM batch'}
            target=dest/f'bucket-{bucket}.json'
            target.write_text(json.dumps(out,ensure_ascii=False,separators=(',',':'))+'\n')
            buckets[bucket]={'mountains':len(batch),'bytes':target.stat().st_size}
        print('batch',bucket,'checked',count,'matched',totals['matchedEdges'],'/',totals['graphEdges'],flush=True)
    (dest/'coverage-v109.json').write_text(json.dumps({'schema':'sanbak-dem-coverage-v109','checked':count,
        'summary':dict(totals),'buckets':buckets,'fullSourceRasterVerified':False,'records':report},ensure_ascii=False,separators=(',',':'))+'\n')
    print(json.dumps({'checked':count,'totals':totals,'buckets':buckets},ensure_ascii=False),flush=True)

if __name__=='__main__':main()
